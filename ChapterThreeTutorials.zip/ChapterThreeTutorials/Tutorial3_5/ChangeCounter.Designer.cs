﻿namespace Tutorial3_5
{
    partial class ChangeCounter
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ChangeCounter));
            this.label1 = new System.Windows.Forms.Label();
            this.fiveCentsPB = new System.Windows.Forms.PictureBox();
            this.fiftyCentsPB = new System.Windows.Forms.PictureBox();
            this.tenCentsPB = new System.Windows.Forms.PictureBox();
            this.twentyFiveCentsPB = new System.Windows.Forms.PictureBox();
            this.outputDescriptionLabel = new System.Windows.Forms.Label();
            this.totalLabel = new System.Windows.Forms.Label();
            this.exitBtn = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.fiveCentsPB)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fiftyCentsPB)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tenCentsPB)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.twentyFiveCentsPB)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(151, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(77, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Click the Coins";
            // 
            // fiveCentsPB
            // 
            this.fiveCentsPB.Image = ((System.Drawing.Image)(resources.GetObject("fiveCentsPB.Image")));
            this.fiveCentsPB.Location = new System.Drawing.Point(12, 38);
            this.fiveCentsPB.Name = "fiveCentsPB";
            this.fiveCentsPB.Size = new System.Drawing.Size(117, 108);
            this.fiveCentsPB.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.fiveCentsPB.TabIndex = 1;
            this.fiveCentsPB.TabStop = false;
            this.fiveCentsPB.Click += new System.EventHandler(this.fiveCentsPB_Click);
            // 
            // fiftyCentsPB
            // 
            this.fiftyCentsPB.Image = ((System.Drawing.Image)(resources.GetObject("fiftyCentsPB.Image")));
            this.fiftyCentsPB.Location = new System.Drawing.Point(135, 152);
            this.fiftyCentsPB.Name = "fiftyCentsPB";
            this.fiftyCentsPB.Size = new System.Drawing.Size(117, 108);
            this.fiftyCentsPB.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.fiftyCentsPB.TabIndex = 2;
            this.fiftyCentsPB.TabStop = false;
            this.fiftyCentsPB.Click += new System.EventHandler(this.fiftyCentsPB_Click);
            // 
            // tenCentsPB
            // 
            this.tenCentsPB.Image = ((System.Drawing.Image)(resources.GetObject("tenCentsPB.Image")));
            this.tenCentsPB.Location = new System.Drawing.Point(135, 38);
            this.tenCentsPB.Name = "tenCentsPB";
            this.tenCentsPB.Size = new System.Drawing.Size(117, 108);
            this.tenCentsPB.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.tenCentsPB.TabIndex = 3;
            this.tenCentsPB.TabStop = false;
            this.tenCentsPB.Click += new System.EventHandler(this.tenCentsPB_Click);
            // 
            // twentyFiveCentsPB
            // 
            this.twentyFiveCentsPB.Image = ((System.Drawing.Image)(resources.GetObject("twentyFiveCentsPB.Image")));
            this.twentyFiveCentsPB.Location = new System.Drawing.Point(12, 152);
            this.twentyFiveCentsPB.Name = "twentyFiveCentsPB";
            this.twentyFiveCentsPB.Size = new System.Drawing.Size(117, 108);
            this.twentyFiveCentsPB.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.twentyFiveCentsPB.TabIndex = 4;
            this.twentyFiveCentsPB.TabStop = false;
            this.twentyFiveCentsPB.Click += new System.EventHandler(this.twentyFiveCentsPB_Click);
            // 
            // outputDescriptionLabel
            // 
            this.outputDescriptionLabel.AutoSize = true;
            this.outputDescriptionLabel.Location = new System.Drawing.Point(300, 116);
            this.outputDescriptionLabel.Name = "outputDescriptionLabel";
            this.outputDescriptionLabel.Size = new System.Drawing.Size(31, 13);
            this.outputDescriptionLabel.TabIndex = 5;
            this.outputDescriptionLabel.Text = "Total";
            // 
            // totalLabel
            // 
            this.totalLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.totalLabel.Location = new System.Drawing.Point(263, 138);
            this.totalLabel.Name = "totalLabel";
            this.totalLabel.Size = new System.Drawing.Size(100, 23);
            this.totalLabel.TabIndex = 6;
            // 
            // exitBtn
            // 
            this.exitBtn.Location = new System.Drawing.Point(153, 275);
            this.exitBtn.Name = "exitBtn";
            this.exitBtn.Size = new System.Drawing.Size(75, 23);
            this.exitBtn.TabIndex = 7;
            this.exitBtn.Text = "Exit";
            this.exitBtn.UseVisualStyleBackColor = true;
            this.exitBtn.Click += new System.EventHandler(this.exitBtn_Click);
            // 
            // ChangeCounter
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(375, 310);
            this.Controls.Add(this.exitBtn);
            this.Controls.Add(this.totalLabel);
            this.Controls.Add(this.outputDescriptionLabel);
            this.Controls.Add(this.twentyFiveCentsPB);
            this.Controls.Add(this.tenCentsPB);
            this.Controls.Add(this.fiftyCentsPB);
            this.Controls.Add(this.fiveCentsPB);
            this.Controls.Add(this.label1);
            this.Name = "ChangeCounter";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.fiveCentsPB)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fiftyCentsPB)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tenCentsPB)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.twentyFiveCentsPB)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox fiveCentsPB;
        private System.Windows.Forms.PictureBox fiftyCentsPB;
        private System.Windows.Forms.PictureBox tenCentsPB;
        private System.Windows.Forms.PictureBox twentyFiveCentsPB;
        private System.Windows.Forms.Label outputDescriptionLabel;
        private System.Windows.Forms.Label totalLabel;
        private System.Windows.Forms.Button exitBtn;
    }
}

