﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class fuelEconomy : Form
    {
        public fuelEconomy()
        {
            InitializeComponent();
        }

        private void calculateBtn_Click(object sender, EventArgs e)
        {
            double miles;   // To hold miles driven
            double gallons; // To hold gallons used
            double mpg;     // To hold MPG

            // Get the miles driven and assign it to
            // the miles variable.
            miles = double.Parse(milesTB.Text);


            // Get the gallons driven and assign it to
            // the gallons variable.
            gallons = double.Parse(gallonsTB.Text);

            // Calculate MPG.
            mpg = miles / gallons;

            // Display the mpg in th mpgLabel control.
            mpgLabel.Text = mpg.ToString();
        }

        private void exitBtn_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
