﻿namespace ChapterThreeTutorials
{
    partial class birthdateString
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dayOfWeekPromptLabel = new System.Windows.Forms.Label();
            this.monthPromptLabel = new System.Windows.Forms.Label();
            this.dayOfmonthPromptLabel = new System.Windows.Forms.Label();
            this.yearPromptLabel = new System.Windows.Forms.Label();
            this.dateOutputLabel = new System.Windows.Forms.Label();
            this.showDateBtn = new System.Windows.Forms.Button();
            this.clearBtn = new System.Windows.Forms.Button();
            this.exitBtn = new System.Windows.Forms.Button();
            this.dayOfWeekTB = new System.Windows.Forms.TextBox();
            this.monthTB = new System.Windows.Forms.TextBox();
            this.dayOfmonthTB = new System.Windows.Forms.TextBox();
            this.yearTB = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // dayOfWeekPromptLabel
            // 
            this.dayOfWeekPromptLabel.AutoSize = true;
            this.dayOfWeekPromptLabel.Location = new System.Drawing.Point(62, 23);
            this.dayOfWeekPromptLabel.Name = "dayOfWeekPromptLabel";
            this.dayOfWeekPromptLabel.Size = new System.Drawing.Size(129, 13);
            this.dayOfWeekPromptLabel.TabIndex = 0;
            this.dayOfWeekPromptLabel.Text = "Enter the day of the week";
            // 
            // monthPromptLabel
            // 
            this.monthPromptLabel.AutoSize = true;
            this.monthPromptLabel.Location = new System.Drawing.Point(50, 49);
            this.monthPromptLabel.Name = "monthPromptLabel";
            this.monthPromptLabel.Size = new System.Drawing.Size(141, 13);
            this.monthPromptLabel.TabIndex = 1;
            this.monthPromptLabel.Text = "Enter the name of the month";
            
            // 
            // dayOfmonthPromptLabel
            // 
            this.dayOfmonthPromptLabel.AutoSize = true;
            this.dayOfmonthPromptLabel.Location = new System.Drawing.Point(19, 76);
            this.dayOfmonthPromptLabel.Name = "dayOfmonthPromptLabel";
            this.dayOfmonthPromptLabel.Size = new System.Drawing.Size(172, 13);
            this.dayOfmonthPromptLabel.TabIndex = 2;
            this.dayOfmonthPromptLabel.Text = "Enter the numeric day of the month";
            // 
            // yearPromptLabel
            // 
            this.yearPromptLabel.AutoSize = true;
            this.yearPromptLabel.Location = new System.Drawing.Point(118, 102);
            this.yearPromptLabel.Name = "yearPromptLabel";
            this.yearPromptLabel.Size = new System.Drawing.Size(73, 13);
            this.yearPromptLabel.TabIndex = 3;
            this.yearPromptLabel.Text = "Enter the year";
           
            // 
            // dateOutputLabel
            // 
            this.dateOutputLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.dateOutputLabel.Location = new System.Drawing.Point(22, 143);
            this.dateOutputLabel.Name = "dateOutputLabel";
            this.dateOutputLabel.Size = new System.Drawing.Size(275, 23);
            this.dateOutputLabel.TabIndex = 4;
            this.dateOutputLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // showDateBtn
            // 
            this.showDateBtn.Location = new System.Drawing.Point(35, 184);
            this.showDateBtn.Name = "showDateBtn";
            this.showDateBtn.Size = new System.Drawing.Size(75, 23);
            this.showDateBtn.TabIndex = 5;
            this.showDateBtn.Text = "Show Date";
            this.showDateBtn.UseVisualStyleBackColor = true;
            this.showDateBtn.Click += new System.EventHandler(this.showDateBtn_Click);
            // 
            // clearBtn
            // 
            this.clearBtn.Location = new System.Drawing.Point(116, 184);
            this.clearBtn.Name = "clearBtn";
            this.clearBtn.Size = new System.Drawing.Size(75, 23);
            this.clearBtn.TabIndex = 6;
            this.clearBtn.Text = "Clear";
            this.clearBtn.UseVisualStyleBackColor = true;
            this.clearBtn.Click += new System.EventHandler(this.button2_Click);
            // 
            // exitBtn
            // 
            this.exitBtn.Location = new System.Drawing.Point(197, 184);
            this.exitBtn.Name = "exitBtn";
            this.exitBtn.Size = new System.Drawing.Size(75, 23);
            this.exitBtn.TabIndex = 7;
            this.exitBtn.Text = "Exit";
            this.exitBtn.UseVisualStyleBackColor = true;
            this.exitBtn.Click += new System.EventHandler(this.exitBtn_Click);
            // 
            // dayOfWeekTB
            // 
            this.dayOfWeekTB.Location = new System.Drawing.Point(197, 20);
            this.dayOfWeekTB.Name = "dayOfWeekTB";
            this.dayOfWeekTB.Size = new System.Drawing.Size(100, 20);
            this.dayOfWeekTB.TabIndex = 8;
            // 
            // monthTB
            // 
            this.monthTB.Location = new System.Drawing.Point(197, 46);
            this.monthTB.Name = "monthTB";
            this.monthTB.Size = new System.Drawing.Size(100, 20);
            this.monthTB.TabIndex = 9;
            // 
            // dayOfmonthTB
            // 
            this.dayOfmonthTB.Location = new System.Drawing.Point(197, 73);
            this.dayOfmonthTB.Name = "dayOfmonthTB";
            this.dayOfmonthTB.Size = new System.Drawing.Size(100, 20);
            this.dayOfmonthTB.TabIndex = 10;
            // 
            // yearTB
            // 
            this.yearTB.Location = new System.Drawing.Point(197, 99);
            this.yearTB.Name = "yearTB";
            this.yearTB.Size = new System.Drawing.Size(100, 20);
            this.yearTB.TabIndex = 11;
            // 
            // birthdateString
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(317, 228);
            this.Controls.Add(this.yearTB);
            this.Controls.Add(this.dayOfmonthTB);
            this.Controls.Add(this.monthTB);
            this.Controls.Add(this.dayOfWeekTB);
            this.Controls.Add(this.exitBtn);
            this.Controls.Add(this.clearBtn);
            this.Controls.Add(this.showDateBtn);
            this.Controls.Add(this.dateOutputLabel);
            this.Controls.Add(this.yearPromptLabel);
            this.Controls.Add(this.dayOfmonthPromptLabel);
            this.Controls.Add(this.monthPromptLabel);
            this.Controls.Add(this.dayOfWeekPromptLabel);
            this.Name = "birthdateString";
            this.Text = "Birth Date String";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label dayOfWeekPromptLabel;
        private System.Windows.Forms.Label monthPromptLabel;
        private System.Windows.Forms.Label dayOfmonthPromptLabel;
        private System.Windows.Forms.Label yearPromptLabel;
        private System.Windows.Forms.Label dateOutputLabel;
        private System.Windows.Forms.Button showDateBtn;
        private System.Windows.Forms.Button clearBtn;
        private System.Windows.Forms.Button exitBtn;
        private System.Windows.Forms.TextBox dayOfWeekTB;
        private System.Windows.Forms.TextBox monthTB;
        private System.Windows.Forms.TextBox dayOfmonthTB;
        private System.Windows.Forms.TextBox yearTB;
    }
}

