﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ChapterThreeTutorials
{
    public partial class birthdateString : Form
    {
        public birthdateString()
        {
            InitializeComponent();
        }

      

        
        private void showDateBtn_Click(object sender, EventArgs e)
        {
            // Declare a string variable.
            string output;

            // Concatenate the input and build the output string.
            output = dayOfWeekTB.Text + "," +
                monthTB.Text + " " +
                dayOfmonthTB.Text + "," +
                yearTB.Text;

            // Display the output string in the Label control.
            dateOutputLabel.Text = output;
                
        }

        private void button2_Click(object sender, EventArgs e)
        {
            // Clear the TextBoxes.
            dayOfWeekTB.Text = "";
            monthTB.Text = "";
            dayOfmonthTB.Text = "";
            yearTB.Text = "";

            // Clear the dateOutputLabel control.
            dateOutputLabel.Text = "";
        }

        private void exitBtn_Click(object sender, EventArgs e)
        {
            // Close the form.
            Close();
        }
    }
}
