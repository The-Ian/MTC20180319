﻿namespace ProgrammingProblems
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.outputLabel = new System.Windows.Forms.Label();
            this.taxOutputLabel = new System.Windows.Forms.Label();
            this.tipOutputLabel = new System.Windows.Forms.Label();
            this.baseFoodChargeTB = new System.Windows.Forms.TextBox();
            this.foodChargeLabel = new System.Windows.Forms.Label();
            this.tipLabel = new System.Windows.Forms.Label();
            this.taxLabel = new System.Windows.Forms.Label();
            this.totalBtn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(50, 147);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(31, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Total";
            // 
            // outputLabel
            // 
            this.outputLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.outputLabel.Location = new System.Drawing.Point(128, 147);
            this.outputLabel.Name = "outputLabel";
            this.outputLabel.Size = new System.Drawing.Size(100, 23);
            this.outputLabel.TabIndex = 1;
            // 
            // taxOutputLabel
            // 
            this.taxOutputLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.taxOutputLabel.Location = new System.Drawing.Point(128, 114);
            this.taxOutputLabel.Name = "taxOutputLabel";
            this.taxOutputLabel.Size = new System.Drawing.Size(100, 23);
            this.taxOutputLabel.TabIndex = 2;
            // 
            // tipOutputLabel
            // 
            this.tipOutputLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tipOutputLabel.Location = new System.Drawing.Point(128, 82);
            this.tipOutputLabel.Name = "tipOutputLabel";
            this.tipOutputLabel.Size = new System.Drawing.Size(100, 23);
            this.tipOutputLabel.TabIndex = 3;
            // 
            // baseFoodChargeTB
            // 
            this.baseFoodChargeTB.Location = new System.Drawing.Point(128, 31);
            this.baseFoodChargeTB.Name = "baseFoodChargeTB";
            this.baseFoodChargeTB.Size = new System.Drawing.Size(100, 20);
            this.baseFoodChargeTB.TabIndex = 4;
            // 
            // foodChargeLabel
            // 
            this.foodChargeLabel.AutoSize = true;
            this.foodChargeLabel.Location = new System.Drawing.Point(50, 34);
            this.foodChargeLabel.Name = "foodChargeLabel";
            this.foodChargeLabel.Size = new System.Drawing.Size(68, 13);
            this.foodChargeLabel.TabIndex = 5;
            this.foodChargeLabel.Text = "Food Charge";
            // 
            // tipLabel
            // 
            this.tipLabel.AutoSize = true;
            this.tipLabel.Location = new System.Drawing.Point(50, 83);
            this.tipLabel.Name = "tipLabel";
            this.tipLabel.Size = new System.Drawing.Size(22, 13);
            this.tipLabel.TabIndex = 6;
            this.tipLabel.Text = "Tip";
            // 
            // taxLabel
            // 
            this.taxLabel.AutoSize = true;
            this.taxLabel.Location = new System.Drawing.Point(50, 115);
            this.taxLabel.Name = "taxLabel";
            this.taxLabel.Size = new System.Drawing.Size(54, 13);
            this.taxLabel.TabIndex = 7;
            this.taxLabel.Text = "Sales Tax";
            // 
            // totalBtn
            // 
            this.totalBtn.Location = new System.Drawing.Point(109, 206);
            this.totalBtn.Name = "totalBtn";
            this.totalBtn.Size = new System.Drawing.Size(75, 23);
            this.totalBtn.TabIndex = 8;
            this.totalBtn.Text = "Calculate";
            this.totalBtn.UseVisualStyleBackColor = true;
            this.totalBtn.Click += new System.EventHandler(this.totalBtn_Click);
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 261);
            this.Controls.Add(this.totalBtn);
            this.Controls.Add(this.taxLabel);
            this.Controls.Add(this.tipLabel);
            this.Controls.Add(this.foodChargeLabel);
            this.Controls.Add(this.baseFoodChargeTB);
            this.Controls.Add(this.tipOutputLabel);
            this.Controls.Add(this.taxOutputLabel);
            this.Controls.Add(this.outputLabel);
            this.Controls.Add(this.label1);
            this.Name = "Form2";
            this.Text = "Form2";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label outputLabel;
        private System.Windows.Forms.Label taxOutputLabel;
        private System.Windows.Forms.Label tipOutputLabel;
        private System.Windows.Forms.TextBox baseFoodChargeTB;
        private System.Windows.Forms.Label foodChargeLabel;
        private System.Windows.Forms.Label tipLabel;
        private System.Windows.Forms.Label taxLabel;
        private System.Windows.Forms.Button totalBtn;
    }
}