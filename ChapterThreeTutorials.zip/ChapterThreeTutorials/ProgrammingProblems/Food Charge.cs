﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProgrammingProblems
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void totalBtn_Click(object sender, EventArgs e)
        {
            try
            {
                // Declare all of your output variables.
                
                double tipOutput;
                double taxOutput;
                double totalOutput;

                tipOutput = Convert.ToDouble(baseFoodChargeTB.Text) * 0.15;

                tipOutputLabel.Text = tipOutput.ToString();

                taxOutput = Convert.ToDouble(baseFoodChargeTB.Text) * 0.07;

                taxOutputLabel.Text = taxOutput.ToString();

                totalOutput = Convert.ToDouble(baseFoodChargeTB.Text)
                    + Convert.ToDouble(tipOutput) + Convert.ToDouble(taxOutput);

                outputLabel.Text = totalOutput.ToString();



            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

             
}
}
