﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProgrammingProblems
{
    public partial class NameFormatter : Form
    {
        public NameFormatter()
        {
            InitializeComponent();
        }


        private void button6_Click(object sender, EventArgs e)
        {
            try
            { 
            // Declare a string variable.
            string output;

            // Concatenate the input and build the output string.
            output = lastNameTB.Text + "," + " " +
                firstNameTB.Text;

            // Display the output string in the Label control.
            outputLabel.Text = output;
            }

            catch (Exception ex)
            {
                // Display the default error message.
                MessageBox.Show(ex.Message);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try {
                string output;

                output = titleTB.Text + " " +
                    firstNameTB.Text + " " +
                    middleNameTB.Text + " " +
                    lastNameTB.Text;

                outputLabel.Text = output;
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                string output;

                output = firstNameTB.Text + " " +
                    middleNameTB.Text + " " +
                    lastNameTB.Text;

                outputLabel.Text = output;

            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                string output;

                output = firstNameTB.Text + " " +
                    lastNameTB.Text;

                outputLabel.Text = output;
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            try
            {
                string output;

                output = lastNameTB.Text + "," + " " +
                    firstNameTB.Text + " " +
                    middleNameTB.Text + "," + " " +
                    titleTB.Text;

                outputLabel.Text = output;
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            try
            {
                string output;

                output = lastNameTB.Text + "," + " " +
                    firstNameTB.Text + " " +
                    middleNameTB.Text;

                outputLabel.Text = output;
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        

      
    }
}
