﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Tutorial3_4
{
    public partial class TestAverage : Form
    {
        public TestAverage()
        {
            InitializeComponent();
        }

        private void calculateBtn_Click(object sender, EventArgs e)
        {
            try
            {
                double test1;   // To hold test score #1
                double test2;   // To hold test score #2
                double test3;   // To hold test score #3
                double average;   // To hold the average test score

                // Get the three test scores.
                test1 = double.Parse(test1TB.Text);
                test2 = double.Parse(test2TB.Text);
                test3 = double.Parse(test3TB.Text);

                // Calculate the average test score.
                average = (test1 + test2 + test3) / 3;

                // Display the average test score, with
                // the output rounded to 1 decimal point.
                averageLabel.Text = average.ToString("n1");
            }

            catch (Exception ex)
            {
                // Display the default error message.
                MessageBox.Show(ex.Message);
            }

        }

        private void clearBtn_Click(object sender, EventArgs e)
        {
            // Clear the input and output controls.
            test1TB.Text = "";
            test2TB.Text = "";
            test3TB.Text = "";
            averageLabel.Text = "";
        }

        private void exitBtn_Click(object sender, EventArgs e)
        {
            // Close the form.
            Close();
        }
    }
}
